#ifndef QHTTP_H
#define QHTTP_H

#include<qnetworkaccessmanager.h>
#include <QObject>


class qhttp:public QObject
{
    Q_OBJECT
public:
    qhttp(QObject *parent = nullptr);
    void sendRequest(const QString &host, int port, const QString &path);



public slots:
    // QString on_sendRequestButton_clicked(QString urlfromui);

private slots:
    void onConnected();
    void onReadyRead();
    void onDisconnected();
signals:
    void msgtoui(QString msg);

public:
    QTcpSocket *socket;
};

#endif // QHTTP_H
