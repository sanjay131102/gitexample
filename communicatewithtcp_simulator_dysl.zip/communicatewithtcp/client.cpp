#include "client.h"
#include<QAbstractSocket>
#include "qapplication.h"

client::client(QObject *parent) : QObject(parent)
{
    socket=new QTcpSocket();

    QObject::connect(qApp, &QApplication::aboutToQuit, this, &client::abortsocket);
}
//read from server called from readyread connect
void client::readfromserver()
{
    QByteArray recmsg= socket->readAll();
    qDebug()<<" Raw data recevied"<<recmsg;
    QString msg1=QString::fromUtf8(recmsg);
    emit recemsg(msg1);
}
//send called from ui
void client::sendclicked(QString message)
{
    QByteArray messageByteArray = message.toUtf8();
    socket->write(messageByteArray);
}
//state change denotes the
void client::statechanged()
{
    int statenum=socket->state();
    if(statenum==0)
    {
        emit state("UnconnectedState");
    }
    else if(statenum==1)
    {
        emit state("HostLookupState");
    }
    else if(statenum==2)
    {
        emit state("ConnectingState");
    }
    else if(statenum==3)
    {
        emit state("ConnectedState");
    }
    else if(statenum==4)
    {
        emit state("BoundState");
    }
    else if(statenum==5)
    {
        emit state("ListeningState");
    }
    else
    {
        socket->disconnectFromHost();
        emit state("ClosingState");
    }
}
//if unconnected state this is called in mainwindow
void client::closesocket()
{
    socket->close();
}
//when conect clicked in ui connection is established
QString client::connectcliked(QString ip, int portnum)
{
    ipadd=ip;
    port=portnum;
    QObject::connect(socket, &QTcpSocket::stateChanged, this, &client::statechanged);
    socket->connectToHost(ipadd,port);
    if (socket->waitForConnected()) {
        QObject::connect(socket, &QTcpSocket::readyRead, this, &client::readfromserver);
       //connect (socket,SIGNAL(disconnected()),this,SLOT(disablebutton()));
       // connect(socket,SIGNAL(connected()),this,SLOT(enablebutton()));
        return "Connected to server";
    } else {
        qDebug() << "Failed to connect to server:" << socket->errorString();
        emit disconnected();
        return "Connected to server Failed";
    }

}
//when ping clicked it is emiting success
QString client::pingclicked(QString ip, int portnum)
{
    ipadd=ip;
    port=portnum;
    socket->connectToHost(ipadd,port);
    // Check if the connection was successful
    if(socket->waitForConnected()) {
        return "Ping successful. Host is reachable.";


    } else {
        qDebug() << "Ping failed. Host is unreachable.";
        return "Ping failed. Host is unreachable.";

    }
}
//this will be called when ui is closed
void client::abortsocket()
{
    socket->abort();
}
void client::disablebutton()
{
    emit disconnected();
}
