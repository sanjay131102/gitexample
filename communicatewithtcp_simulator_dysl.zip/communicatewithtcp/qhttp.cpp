#include "qhttp.h"
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include<QDir>
#include<qfile.h>
#include<QTcpSocket>

qhttp::qhttp(QObject *parent) : QObject(parent)
{
    socket =new QTcpSocket;
    connect(socket, &QTcpSocket::connected, this, &qhttp::onConnected);
    connect(socket, &QTcpSocket::readyRead, this, &qhttp::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &qhttp::onDisconnected);
}





void qhttp::sendRequest(const QString &host, int port, const QString &path)
{
    socket->connectToHost(host, port);
    if (!socket->waitForConnected(5000)) {
        qDebug() << "Connection failed!";
        return;
    }

    QString request = QString("GET %1 HTTP/1.1\r\n"
                              "Host: %2\r\n"
                              "Connection: close\r\n\r\n")
                          .arg(path)
                          .arg(host);
    socket->write(request.toUtf8());

}

void qhttp::onConnected()
{
    qDebug() << "Connected to server";
    emit msgtoui("Connected to server");
}

void qhttp::onReadyRead()
{
    QByteArray response = socket->readAll();
    qDebug() << "Response received:";
    qDebug() << response;
    emit msgtoui("Response received:"+response);
}

void qhttp::onDisconnected()
{
    qDebug() << "Disconnected from server";
    emit msgtoui("Connected to server");
}
