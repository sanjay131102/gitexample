#ifndef UDP_H
#define UDP_H

#include <QObject>
#include<QUdpSocket>
#include<qtimer.h>
#include <QQueue>
#include <QByteArray>
struct RadarModeStatus
{
    quint32 oper_mode;   //   0/non-op  1/oper
    quint32 connectiviy;//    0/false   1/true
    quint32 ready_mode;//     1/ready   2/not ready
    quint32 free_mode;//      0/off     1/on
    quint32 init_mode;//      0/off  1/init completed  2/init failed
    quint32 rec_status;//     0/off  1/on
};
struct TimedPacket
{
    QByteArray data;
    int delayMs;   // delay BEFORE sending this packet
};

class udp:public QObject
{
    Q_OBJECT
public:
    udp(QObject *parent = nullptr);
    void sendMessage(const QByteArray &message, const QHostAddress &senderAddress, quint16 sendPort);
    QString connect(QString ip, int localportnum);
    void closeudpsocket();

    RadarModeStatus sts_packet={3,3,3,3,3,3};
    QString sendCsvRowsAsUdp_30ms(const QHostAddress& targetIp, quint16 targetPort);
    void startSimulator(const QHostAddress& addr, quint16 port);

public slots:
    void readPendingDatagrams();
    void sendTick();
    void onSendTimeout();
signals:
    void readmessage(QString message,const QHostAddress &recevierAddress, quint16 Port);
public:
    QUdpSocket *udpSocket;
    int port;
    QQueue<QByteArray> packetQueue;
    QTimer *csvSendTimer = nullptr;

    QVector<TimedPacket> originalPackets;
    int currentIndex = 0;
    int repeatCount = 0;
    const int MAX_REPEAT = 1;



    //db test data
    QTimer sendTimer;

    QByteArray m_message;
    QHostAddress m_address;
    quint16 m_port = 0;
    int m_count = 0;

};

#endif // UDP_H
