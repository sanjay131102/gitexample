#include "udp.h"
#include "mainwindow.h"
#include <QUdpSocket>

#include"QRandomGenerator"
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include<QQueue>
udp::udp(QObject *parent) : QObject(parent)
{
    // Create a UDP socket
    udpSocket = new QUdpSocket(this);


    sendTimer.setInterval(100);   // 100 ms
    QAbstractSocket::connect(&sendTimer, &QTimer::timeout,
            this, &udp::onSendTimeout);
}

void udp::sendMessage(const QByteArray &message,
                       const QHostAddress &address,
                       quint16 port)
{
    m_message = message;
    m_address = address;
    m_port = port;
    m_count = 0;

    sendTimer.start();
}
void udp::startSimulator(const QHostAddress& addr, quint16 port)
{
    m_address = addr;
    m_port = port;
    sendTimer.start(500);
}

void udp::onSendTimeout()
{
    // 🔥 GENERATE NEW DATA EVERY TIME
    QByteArray message;

    QDataStream stream(&message, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);

    auto* rng = QRandomGenerator::system();

    quint16 id = 99;
    ModuleType module = static_cast<ModuleType>(rng->bounded(3));

    quint16 index =
        (module == ModuleType::ADC) ? rng->bounded(16) : rng->bounded(64);

    QString sub =
        (module == ModuleType::TX)  ? QStringList{"PA","BPF"}[rng->bounded(2)] :
            (module == ModuleType::RX)  ? QStringList{"LNA","PA","LIMITOR"}[rng->bounded(3)] :
            QStringList{"NA","LNA"}[rng->bounded(2)];

    HealthState st = static_cast<HealthState>(rng->bounded(3));

    QByteArray data;
    QDataStream ds(&data, QIODevice::WriteOnly);
    ds.setByteOrder(QDataStream::LittleEndian);
    ds << quint8(module) << index << sub << quint8(st);

    quint16 len = sizeof(id) + sizeof(len) + data.size();

    stream << id << len;
    message.append(data);
    qDebug()<<id<<&module<<sub<<&st;
    udpSocket->writeDatagram(message, m_address, m_port);
}

void udp::sendTick()
{
    if (m_count >= 1000) {
        sendTimer.stop();
        qDebug() << "Finished sending 1000 messages";
        return;
    }

    qint64 bytes =
        udpSocket->writeDatagram(m_message, m_address, m_port);

    if (bytes == -1) {
        qWarning() << "UDP write failed:" << udpSocket->errorString();
    } else {
        qDebug() << "Sent packet" << m_count + 1;
    }

    ++m_count;
}



void udp::readPendingDatagrams()
{
    while (udpSocket->hasPendingDatagrams())
    {
        //--------------------------------------------------
        // 1) Read entire UDP datagram
        //--------------------------------------------------
        QByteArray block;
        block.resize(udpSocket->pendingDatagramSize());

        QHostAddress sender;
        quint16 senderPort = 0;

        udpSocket->readDatagram(block.data(), block.size(), &sender, &senderPort);

        QDataStream stream(block);
        stream.setByteOrder(QDataStream::LittleEndian);

        //--------------------------------------------------
        // 2) Extract ID + LEN
        //--------------------------------------------------
        quint16 id = 0;
        quint16 len = 0;

        stream >> id;   // 2 bytes
        stream >> len;  // 2 bytes

        //--------------------------------------------------
        // 3) Validate and extract DATA
        //--------------------------------------------------
        int payloadSize = len;              // len = data bytes count
        int available = block.size() - 6;   // after ID+LEN

        // if (payloadSize < 0 || payloadSize > available)
        // {
        //     qWarning() << "Invalid LEN:" << block.data()
        //                << "ID:" << id
        //                << "Available:" << available
        //                << "PacketSize:" << block.size();
        //     continue;
        // }

        QByteArray payload = block.mid(4, payloadSize);

        qDebug() << "ID   :" << id;
        qDebug() << "LEN  :" << len;
        qDebug() << "DATA :" << payload.toHex(' ');


        //--------------------------------------------------
        // 4) Decode DATA (your switch)
        //--------------------------------------------------
        QDataStream ds(payload);
        ds.setByteOrder(QDataStream::LittleEndian);

        switch (id)
        {
        case 101:
        {
            sts_packet.oper_mode=payload.toHex(' ').toInt();
            break;
        }
        case 103:
        {
            sts_packet.ready_mode=payload.toHex(' ').toInt();
            break;
        }
        case 104:
        {
            sts_packet.free_mode=payload.toHex(' ').toInt();
            break;
        }
        case 107:
        {
            sts_packet.init_mode=payload.toHex(' ').toInt();
            break;
        }
        case 100:
        {
            sts_packet.oper_mode=payload.toHex(' ').toInt();
            break;
        }
        case 99:
        {
            sts_packet.oper_mode=payload.toHex(' ').toInt();
            break;
        }
            // -----------------------------------------
            // Add more cases here …
            // -----------------------------------------

        default:
            qDebug() << "Unknown ID:" << id;
            break;
        }

        //--------------------------------------------------
        // Emit original packet if needed
        //--------------------------------------------------
        emit readmessage(block, sender, senderPort);

    } // end while
}
QString udp::connect(QString ip,int localportnum)
{
    if(udpSocket->bind(QHostAddress(ip), localportnum))
    {
        QAbstractSocket::connect(udpSocket, &QUdpSocket::readyRead, this, &udp::readPendingDatagrams);
        QAbstractSocket::connect(udpSocket,&QUdpSocket::disconnected,this,&udp::closeudpsocket);
        return "Connected";
    }else
    {
        return "Not connected";
    }

}

void udp::closeudpsocket()
{
    udpSocket->close();
}
QString udp::sendCsvRowsAsUdp_30ms(
    const QHostAddress& targetIp,
    quint16 targetPort)
{
    const QString fileName =
        "/home/sanjays/DYSLCTWS/test_data/test_data (copy).csv";

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return "Failed to open CSV";

    QTextStream in(&file);

    originalPackets.clear();
    currentIndex = 0;
    repeatCount = 0;

    int lineNo = 0;

    while (!in.atEnd())
    {
        lineNo++;
        QString line = in.readLine().trimmed();
        if (line.isEmpty())
            continue;

        QStringList c = line.split(',', Qt::KeepEmptyParts);
        bool ok = true;

        if (c.size() != 55) {
            qWarning() << "Invalid CSV column count at line"
                       << lineNo << "got" << c.size();
            continue;
        }

        // ===== TIME INTERVAL (ms) =====
        double intervalMsD = c[0].toDouble(&ok);
        if (!ok || intervalMsD < 0.0)
            continue;

        int delayMs = qRound(intervalMsD);

        // ===== HEADER =====
        qint16 blkID  = c[1].toInt(&ok);
        qint16 blkLen = c[2].toInt(&ok);

        if (blkID != 151 || blkLen != 208)
            continue;

        // ===== PAYLOAD =====
        QByteArray payload;
        QDataStream ds(&payload, QIODevice::WriteOnly);
        ds.setByteOrder(QDataStream::LittleEndian);
        ds.setFloatingPointPrecision(QDataStream::SinglePrecision);

        ds << qint16(c[3].toInt(&ok));
        ds << qint16(c[4].toInt(&ok));

        ds << qint32(c[5].toInt(&ok));
        ds << qint32(c[6].toInt(&ok));
        ds << qint32(c[7].toInt(&ok));

        ds << qint16(c[8].toInt(&ok));
        ds << qint16(c[9].toInt(&ok));

        ds << qint32(c[10].toInt(&ok));

        for (int i = 11; i <= 19; ++i) ds << c[i].toFloat(&ok);
        for (int i = 20; i <= 25; ++i) ds << c[i].toFloat(&ok);
        for (int i = 26; i <= 31; ++i) ds << c[i].toFloat(&ok);
        for (int i = 32; i <= 37; ++i) ds << c[i].toFloat(&ok);

        ds << qint8 (c[38].toInt(&ok));
        ds << qint16(c[39].toInt(&ok));
        ds << qint16(c[40].toInt(&ok));

        ds << qint32(c[41].toInt(&ok));
        for (int i = 42; i <= 44; ++i) ds << c[i].toFloat(&ok);
        for (int i = 45; i <= 50; ++i) ds << c[i].toFloat(&ok);

        ds << qint8(c[51].toInt(&ok));
        ds << c[52].toFloat(&ok);
        ds << c[53].toFloat(&ok);
        ds << c[54].toFloat(&ok);

        if (!ok || payload.size() != (194 - 4))
            continue;

        QByteArray packet;
        QDataStream out(&packet, QIODevice::WriteOnly);
        out.setByteOrder(QDataStream::LittleEndian);
        out << blkID << blkLen;
        packet.append(payload);

        originalPackets.push_back({ packet, delayMs });
    }

    file.close();

    if (originalPackets.isEmpty())
        return "No valid TRACK packets";

    // ===== SEND ENGINE (500 RUNS) =====
    if (!csvSendTimer)
    {
        csvSendTimer = new QTimer(this);
        csvSendTimer->setSingleShot(true);

        QAbstractSocket::connect(csvSendTimer, &QTimer::timeout, this,
                [=]() mutable {

                    if (currentIndex >= originalPackets.size())
                    {
                        currentIndex = 0;
                        repeatCount++;

                        if (repeatCount >= 500)
                        {
                            qDebug() << "TRACK send completed";
                            return;
                        }
                    }

                    const TimedPacket& pkt = originalPackets[currentIndex++];

                    qDebug() << "Next packet delay(ms):" << pkt.delayMs;

                    udpSocket->writeDatagram(pkt.data, targetIp, targetPort);
                    csvSendTimer->start(pkt.delayMs);
                });
    }

    csvSendTimer->start(0);
    return "Binary TRACK_DATA sender started (500 runs)";
}
