#ifndef SERVER_H
#define SERVER_H


#include <QObject>
#include<QTcpServer>
#include<QTcpSocket>

class server:public QObject
{
    Q_OBJECT
public:
    server(QObject *parent = nullptr);
    void onNewConnection();
    QString listen(int num);
    void closeserver();
signals:
    void sendmsg(QString msg);
    void sendfromserver(QString msg);
public:
    QTcpServer *Servertcp;
    int port;
};

#endif // SERVER_H
