#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include "QRandomGenerator"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Server=new server;
    Client=new client;
    Udp=new udp;
    http=new qhttp;


    connect(Client,SIGNAL(recemsg(QString)),this,SLOT(readfromserver(QString)));
    connect(Client,SIGNAL(state(QString)),this,SLOT(readfromserver(QString)));
    connect(Client,SIGNAL(disconnected()),this,SLOT(disablebutton()));
    connect(Server,SIGNAL(sendmsg(QString)),this,SLOT(readfromclient(QString)));
    connect(Udp, &udp::readmessage, this, [this](QString message, QHostAddress address, quint16 port){
        readfromudp(message, address, port);
    });
    connect(http,SIGNAL(msgtoui(QString)),SLOT(toprintfromhttp(QString)));
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::on_connect_clicked()
{
    if(f==0)
    {
        ip=ui->ipaddress->text();
        portnum=ui->portnumber->text().toInt();
        QString status=Client->connectcliked(ip,portnum);
        ui->console->appendPlainText(status);
        if(status=="Connected to server")
        {
        ui->connect->setText("Disconnect");
        ui->connect->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(198, 70, 0)");
        f=1;
        }
    }else
    {
        Client->abortsocket();
        ui->connect->setText("Connect---");
        ui->connect->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(38, 162, 105);");
        f=0;
    }
}


void MainWindow::on_ping_clicked()
{
    ip=ui->ipaddress->text();
    portnum=ui->portnumber->text().toInt();
    ui->console->appendPlainText(Client->pingclicked(ip,portnum));
}


void MainWindow::on_send_clicked()
{
    QString message =ui->message->text();
    Client->sendclicked(message);
    ui->console->appendPlainText("SENDINGG---"+message);
   // qDebug()<<"coming inside main send";

}

void MainWindow::readfromserver(QString msg)
{
    ui->console->appendPlainText(msg);
    if(msg=="UnconnectedState"||msg=="Connected to server Failed")
    {
        Client->closesocket();
        //ui->connect->setDisabled(false);
        ui->connect->setText("Connect---");
        ui->connect->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(38, 162, 105);");
        f=0;
    }

}

void MainWindow::readfromclient(QString msg)
{
    qDebug()<<"coming inside main read";
    ui->console_server->appendPlainText("RECEVING MESSAGE----"+msg);
}


void MainWindow::on_listen_clicked()
{
    int portserver=ui->portnumber_server->text().toInt();
    qDebug()<<portserver;
    ui->console_server->appendPlainText(Server->listen(portserver));
    if(a==0)
    {
        ui->listen->setText("STOP");
        ui->listen->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(165, 29, 45);");
        a=1;
    }else
    {
        Server->closeserver();
        ui->listen->setText("LISTEN");
        ui->listen->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(38, 162, 105);");
        a=0;
    }
}


void MainWindow::on_send_server_clicked()
{
    QString message=ui->message_server->text();
    emit Server->sendfromserver(message);
    ui->console_server->appendPlainText("SENDING MESSAGE----"+message);
}

//clear console in client
void MainWindow::on_pushButton_clicked()
{
    ui->console->clear();
}
void MainWindow::disablebutton()
{
    qDebug()<<"comingg in disable";
    Client->closesocket();
    Client->abortsocket();
    ui->connect->setText("Connect-xxxx");
    ui->connect->setStyleSheet("color: rgb(255, 255, 255);background-color: rgb(0, 0, 0);");
    f=0;
}
//clear console in udp
void MainWindow::on_pushButton_2_clicked()
{
    ui->console_upd->clear();
}

//connect udp and close
void MainWindow::on_connect_upd_clicked()
{
    if(u==0)
    {
        QString ip=ui->ipaddress_udp->text();
        int localport=ui->localport_udp->text().toInt();
        ui->console_upd->appendPlainText(Udp->connect(ip,localport));
        ui->connect_upd->setText("Close");
        ui->connect_upd->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(165, 29, 45);");
        u=1;
    }else
    {
        Udp->closeudpsocket();
        ui->connect_upd->setText("Connect---");
        ui->connect_upd->setStyleSheet("color: rgb(0, 0, 0);background-color: rgb(38, 162, 105);");
        u=0;
    }
}

//send udp
void MainWindow::on_send_udp_clicked()
{
    // ----------------------------
    // 1) Simulator values
    // ----------------------------
    // quint16 id = 99;   // frame ID (keep if receiver expects it)

    // ModuleType module = static_cast<ModuleType>(QRandomGenerator::global()->bounded(3));
    // quint16 moduleIndex = QRandomGenerator::global()->bounded(16); // 0–15

    // QStringList txSubs  = {"PA", "BPF"};
    // QStringList rxSubs  = {"LNA", "PA", "LIMITOR"};
    // QStringList adcSubs = {"NA", "LNA"};

    // QString submodule;
    // switch (module)
    // {
    // case ModuleType::TX:  submodule = txSubs.at(QRandomGenerator::global()->bounded(txSubs.size())); break;
    // case ModuleType::RX:  submodule = rxSubs.at(QRandomGenerator::global()->bounded(rxSubs.size())); break;
    // case ModuleType::ADC: submodule = adcSubs.at(QRandomGenerator::global()->bounded(adcSubs.size())); break;
    // }

    // HealthState state =
    //     static_cast<HealthState>(QRandomGenerator::global()->bounded(3)); // OK/WARN/FAIL

    // // ----------------------------
    // // 2) Build DATA payload
    // // ----------------------------
    // QByteArray data;
    // QDataStream ds(&data, QIODevice::WriteOnly);
    // ds.setByteOrder(QDataStream::LittleEndian);

    // ds << static_cast<quint8>(module);      // 1 byte
    // ds << moduleIndex;                      // 2 bytes
    // ds << submodule;                        // QString
    // ds << static_cast<quint8>(state);       // 1 byte

    // // ----------------------------
    // // 3) Frame length
    // // ----------------------------
    // quint16 len = sizeof(id) + sizeof(len) + data.size();

    // // ----------------------------
    // // 4) Build final frame
    // // ----------------------------
    // QByteArray message;
    // QDataStream stream(&message, QIODevice::WriteOnly);
    // stream.setByteOrder(QDataStream::LittleEndian);

    // stream << id;
    // stream << len;
    // message.append(data);

    // // ----------------------------
    // // 5) Send
    // // ----------------------------
    // if (!Udp)
    // {
    //     qCritical() << "Udp pointer is NULL";
    //     return;
    // }

    // QString ip   = ui->ipaddress_udp->text();
    // quint16 port = ui->portnumber_udp->text().toUShort();

    // Udp->sendMessage(message, QHostAddress(ip), port);

    // qDebug() << "SIM HEALTH SENT:"
    //          << "Module=" << static_cast<int>(module)
    //          << "Index=" << moduleIndex
    //          << "Sub=" << submodule
    //          << "State=" << static_cast<int>(state);



    if (!Udp) return;

    Udp->startSimulator(
        QHostAddress(ui->ipaddress_udp->text()),
        ui->portnumber_udp->text().toUShort());
}
void MainWindow::readfromudp(QString message, QHostAddress address, quint16 port)
{
    on_pushButton_4_clicked();
    ui->console_upd->appendPlainText("Receving---"+message);
    qDebug()<<"coming in recevie";
}

void MainWindow::on_send_http_clicked()
{
    // QString url=ui->message_http->text();
    // ui->console_http->appendPlainText(http->on_sendRequestButton_clicked(url));

}

void MainWindow::toprintfromhttp(QString msg)
{
    qDebug()<<"coming in printtt";

    ui->console_http->appendPlainText(msg);
}


void MainWindow::on_pushButton_4_clicked()
{
    // ----------------------------
    // 1) Set your values here
    // ----------------------------
    quint16 id  = 131;   // your command ID
    quint32 v1 = Udp->sts_packet.oper_mode;
    quint32 v2 = Udp->sts_packet.connectiviy;
    quint32 v3 = Udp->sts_packet.ready_mode;
    quint32 v4 = Udp->sts_packet.free_mode;
    quint32 v5 = Udp->sts_packet.init_mode;
    quint32 v6 = Udp->sts_packet.rec_status;


    qDebug() << v3;
    // ----------------------------
    // 2) Build DATA section only
    // ----------------------------
    QByteArray data;
    QDataStream ds(&data, QIODevice::WriteOnly);
    ds.setByteOrder(QDataStream::LittleEndian);

    ds << v1 << v2 << v3 << v4 << v5 << v6;

    // DATA size = 6 * 4 = 24 bytes
    // LEN = sizeof(ID) + sizeof(DATA)
    quint16 len = sizeof(id) + data.size()+2;

    // ----------------------------
    // 3) Build final message frame
    // ----------------------------
    QByteArray message;
    QDataStream stream(&message, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);

    stream << id;      // 2 bytes
    stream << len;     // 2 bytes
    message.append(data);  // append DATA (24 bytes)

    // ----------------------------
    // 4) Send it
    // ----------------------------
    QString ip = ui->ipaddress_udp->text();   // or wherever your ip comes from
    QString port1 = ui->portnumber_udp->text();             // already defined in your class
    quint16 port = port1.toUShort();             // already defined in your class

    Udp->sendMessage(message, QHostAddress(ip), port);

    qDebug() << "Sent Frame:"
             << "ID=" << id
             << "LEN=" << len
             << "DATA=" << data.toHex();
}


void MainWindow::on_pushButton_5_clicked()
{
    QString ip = ui->ipaddress_udp->text();   // or wherever your ip comes from
    QString port1 = ui->portnumber_udp->text();             // already defined in your class
    quint16 port = port1.toUShort();             // already defined in your class

    Udp->sendCsvRowsAsUdp_30ms(QHostAddress(ip), port);
}

