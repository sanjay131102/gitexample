#include "server.h"

server::server(QObject *parent) : QObject(parent)
{
    Servertcp = new QTcpServer(this);
    QObject::connect(Servertcp, &QTcpServer::newConnection, this, &server::onNewConnection);
}
//every time new connection is made new sockket willbe created and readyread,disconnect,sending message will happen here.
void server::onNewConnection()
{
    QTcpSocket *newSocket = Servertcp->nextPendingConnection();
    if (newSocket) {
        QObject::connect(newSocket, &QTcpSocket::readyRead, this, [this, newSocket]() {
            QByteArray recmsg = newSocket->readAll();
            QString msg1 = QString::fromUtf8(recmsg);
            emit sendmsg(msg1);
        });
        QObject::connect(newSocket, &QTcpSocket::disconnected, this, [newSocket]() {
            newSocket->close();
            newSocket->deleteLater();
        });
        QObject::connect(this, &server::sendfromserver, this, [newSocket](const QString &message) {
            if (newSocket && newSocket->state() == QAbstractSocket::ConnectedState) {
                QByteArray data = message.toUtf8();
                newSocket->write(data);
                newSocket->flush();
                qDebug() << "mesageee" << message;
            } else {
                qDebug() << "Socket is not valid or not connected.";
            }
        });
    }
}
//liten is happening with port num from ui.
QString server::listen(int num)
{
    if (Servertcp->listen(QHostAddress::Any, num)) {
        return "Server is listening on port " + QString::number(num);
    } else {
        return "Failed to start server!";
    }
}
//closeing server if it is listening from ui
void server::closeserver()
{
    if (Servertcp->isListening()) {
        Servertcp->close();
    }
}
