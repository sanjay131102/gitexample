#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"client.h"
#include"server.h"
#include"udp.h"
#include"qhttp.h"




QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

enum class HealthState : quint8
{
    Ok = 0,
    Warning = 1,
    Fault = 2,
    Unknown = 3
};

enum class ModuleType : quint8
{
    TX  = 0,
    RX  = 1,
    ADC = 2
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_connect_clicked();
    void on_ping_clicked();
    void on_send_clicked();
    void readfromserver(QString msg);
    void readfromclient(QString msg);
    void disablebutton();
    void on_listen_clicked();
    void on_send_server_clicked();
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_connect_upd_clicked();

    void on_send_udp_clicked();
    void readfromudp(QString message,QHostAddress address,quint16 port);

    void on_send_http_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

public slots:
    void toprintfromhttp(QString msg);

private:
    Ui::MainWindow *ui;
    client *Client;
    server *Server;
    udp *Udp;
    qhttp *http;
    QString ip;
    int portnum;
    int f=0;
    int a=0;
    int u=0;
    int h=0;

};
#endif // MAINWINDOW_H
