#ifndef CLIENT_H
#define CLIENT_H
#include<QTcpSocket>

class client : public QObject
{
    Q_OBJECT
public:
    explicit client(QObject *parent = nullptr);
    void readfromserver();
    QString connectcliked(QString ip, int portnum);
    QString pingclicked(QString ip, int portnum);
    void sendclicked(QString message);
    void statechanged();
    void closesocket();
    void abortsocket();
public slots:
    void disablebutton();





signals:
    void recemsg(QString msg);
    void state(QString sta);
    void disconnected();
    void connectedtoserver();



public:

    int f1=0;
    QTcpSocket *socket;
    QString ipadd;
    int port;
};

#endif // CLIENT_H
